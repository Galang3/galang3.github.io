<!DOCTYPE HTML>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Tentang Galang23 - Galang23</title>
	<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<body>
	<div id="header">
		<div>
			<div class="logo">
				<a href="/">Galang23</a>
			</div>
			<ul id="navigation">
				<li>
					<a href="/">Beranda</a>
				</li>
				<li>
					<a href="/features/">Fitur</a>
				</li>
				<li>
					<a href="/news/">Berita</a>
				</li>
				<li class="active">
					<a href="about.html">Tentang</a>
				</li>
<!--				<li>
					<a href="contact.html">Contact</a>
				</li> -->
			</ul>
		</div>
	</div>
	<div id="contents">
		<div id="about">
			<h1>Tentang Galang23</h1>
			<h2>Siapakah Galang23?</h2>
			<p>
				Galang23 memiliki nama asli Suwarna Adhi Galang Wicaksono dan tertarik dengan ilmu komputer <br/>
				Tidak semua anak muda di Negeri ini tertarik dengan ilmu komputer karena ilmu komputer adalah ilmu yang susah dipahami oleh sebagian besar anak muda.<br/>
				Sebenarnya ilmu komputer mudah dipahami jika dipelajari dari awal seperti mempelajari Microsoft Office Word, Microsoft Office PowerPoint dan lainnya. Hingga mempelajarinya ke bahasa pemrograman dasar seperti HTML dan CSS hingga pada akhirnya mempelajari bahasa pemrograman tingkat lanjut seperti C++, Java, dan JavaScript
			</p>
			<h2>Darimanakah Galang23?</h2>
			<p>
				Galang23 berasal dari Blitar yang memiliki Kartu Keluarga dari Sidoarjo dan sekarang tinggal di Surabaya.
				Lahir pada hari Jum'at Legi tanggal 04 Juli 2003.
			</p>
			
			<h2>Dimanakah Galang23 Bersekolah?</h2>
			<p>
				Sekarang dia kelas I, bersekolah di <a href= "http://smpn3sby.sch.id">SMP Negeri 3 Surabaya</a>
			</p>
			<center>
				<h2>
					Terima Kasih Sudah Mengunjungi Website-ku yang Biasa Saja!
				</h2>
			</center>
<!--			<p>
				Design version 9<br/> Code version 3<br/> Website Template details, discussion and updates for this <a href="http://www.freewebsitetemplates.com/discuss/zerotype/">Zerotype Website Template</a>.<br> Website Template design by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a>.<br> Please feel free to remove some or all the text and links of this page and replace it with your own About content.
			</p>  -->
		</div>
	</div>
	<div id="footer">
		<div class="clearfix">
			<div id="connect">
				<a href="http://facebook.com/swarnaadhi.galangwicaksono" target="_blank" alt="Galang23 di acebook">
				               <img src="https://avatars0.githubusercontent.com/u/69631?v=3&s=200" height="27" width="27">
				               </img>
			   </a>
				<a href="https://plus.google.com/u/0/109238318835174658872/" target="_blank" alt="Galang23 di Google+">
				<img src="https://scontent-sin1-1.xx.fbcdn.net/hphotos-xft1/v/t1.0-9/10369144_507856146050857_3604607975389879946_n.jpg?oh=72870fddbba5c4efd6d611cc084196b5&oe=570EE305" width="27" height="27" />
				</a>
				<a href="http://github.com/Galang23/" target="_blank" class="github" alt="Galang23 di GitHub">
				<img src="http://avatars3.githubusercontent.com/u/9919?v=3&s=200" alt="Galang23 on GitHub" width="27" height="27" />
				</a>
			</div>
			<p>
				© 2013 Zerotype. All Rights Reserved.<br/>
				<i>Hosting</i> Oleh <a href="https://github.com"> GitHub </a>
			</p>
		</div>
	</div>
</body>
</html>

<!-- 
<iframe scrolling="no" frameborder="no" clocktype="html5" style="overflow:hidden;border:0;margin:0;padding:0;width:120px;height:40px;"src="http://www.clocklink.com/html5embed.php?clock=004&timezone=GMT0700&color=orange&size=120&Title=&Message=&Target=&From=2015,1,1,0,0,0&Color=orange"></iframe>
-->